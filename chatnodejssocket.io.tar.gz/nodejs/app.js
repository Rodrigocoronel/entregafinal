/*



*/
var express = require('express');

var app = express();
var server = require('http').Server(app);
var io = require('socket.io').listen(server);



users = []; //guardar los usuarios
connections = []; //guardar las conexiones

server.listen(process.env.PORT || 3000); //inicia el server


console.log("chat running at port 3000");

app.get('/', function(req, res) { 


		res.sendFile(__dirname + "/index.html"); //redirecciona a index.html que muestra el contenido del lado del cliente

	});


io.on('connection', function(socket){ //funcion para conectar socket.io
	
	connections.push(socket);
	console.log('connected: %s sockets connected',connections.length); //imprimir conecciones
	updateUserNames();
	
	//disconnect

	socket.on('disconnect',function(data){ //en caso de desconexion quitar un usuario y actualizarlos
	
	users.splice(users.indexOf(socket.username),1);
	updateUserNames();
	connections.splice(connections.indexOf(socket),1);
	console.log('disconnected: %s sockets connected', connections.length);
	
	});

	

	// Send Message
	socket.on('send message',function(data){ //para mandar el mensaje, mensaje y usuario
		console.log(data);
		io.emit('new message',{msg : data, user : socket.username});
	});

	socket.on('new user',function(data,callback){  //agregar nuevo usuario
		callback(true);
		socket.username = data;
		users.push(socket.username);
		updateUserNames();
	});
	function updateUserNames(){ // mandarle al cliente los usuarios
		io.emit('get users', users);
	}
});
