# nodejs-api-mysql
Api restful + mysql + nodejs
Este codigo es para ejemplificar de una manera basica como realizar una API con nodejs accediendo a una base de datos MySQL
