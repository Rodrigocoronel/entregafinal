<?php
/**
 * Step 1: Require the Slim Framework
 *
 * If you are not using Composer, you need to require the
 * Slim Framework and register its PSR-0 autoloader.
 *
 * If you are using Composer, you can skip this step.
 */
require 'Slim/Slim.php';
require 'includes/meekrodb.2.2.class.php';
require 'includes/functions.php';

\Slim\Slim::registerAutoloader();

/**
 * Step 2: Instantiate a Slim application
 *
 * This example instantiates a Slim application using
 * its default settings. However, you will usually configure
 * your Slim application now by passing an associative array
 * of setting names and values into the application constructor.
 */
$app = new \Slim\Slim();

/**
 * Step 3: Define the Slim application routes
 *
 * Here we define several Slim application routes that respond
 * to appropriate HTTP request methods. In this example, the second
 * argument for `Slim::get`, `Slim::post`, `Slim::put`, `Slim::patch`, and `Slim::delete`
 * is an anonymous function.
 */


DB::$user='rodrigo';
DB::$password='Y0XpaeNsgSM5Ixn7';
DB::$dbName='chat';
DB::$host='localhost';
DB::$encoding='utf8';


$app->get(
    '/listaAmigos/:usuario',
    function ($usuario) use ($app){
    $points = DB::query("SELECT * FROM amigo where usuario = '$usuario'");
    $app->response()->header('Content-Type', 'application/json; charset=utf-8');
    array_walk($points, 'utf8_encode_array');
    echo json_encode($points);

});


$app->post(
    '/login', 
    function() use ($app){

   	
    $email = $_POST['email'];
    $password = $_POST['password'];
    $datos = DB::query("SELECT * FROM usuario where email like '$email' and password = '$password'");

    if(count($datos)==0){
    	 //$app->response()->header('Content-Type', 'application/json; charset=utf-8');
    //echo json_encode("no");
    //echo "no";
    	//return json_encode("false");
    	echo json_encode("no");
   
}
	else{
		// $app->response()->header('Content-Type', 'application/json; charset=utf-8');
		//echo json_encode($datos);
		//echo "si";
		echo json_encode("si");
		//return json_encode("true");

	}
	
});


$app->post(
    '/registro',
    function () use ($app){

    
    $nombre1=$_POST['nombres'];
    $nombre2=$_POST['apellidos'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $nombre=$nombre1 ." ". $nombre2;

    $validar = DB::query("SELECT email from usuario where email like '$email' ");
    
    //echo json_encode($validar);

   
    if(count($validar)==0){
    
    $insertar = DB::query("
                            INSERT INTO usuario (nombre, email, password)
                            VALUES ('$nombre', '$email', '$password')
                            " );
    
    echo json_encode("si");

    } else{
       echo json_encode("no");
     }
  
});


$app->run();
?>