<?php
	function utf8_encode_array (&$array, $key) {
	  if(is_array($array)) {
	    array_walk ($array, 'utf8_encode_array');
	  } else {
	    $array = utf8_encode($array);
	  }
	}
?>