
<!DOCTYPE html>
  <html>
    <head>
        <!--Import Google Icon Font-->
        <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <!--Import materialize.css-->
        <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
        <script type="text/javascript" src="js/jquery-3.2.1.js"></script>
        <!--Let browser know website is optimized for mobile-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    </head>

    <body>
      <div class="row ">
        <form class="col s12 offset-l3" method="post"  >
            <div class="row">
              <div class="input-field col s12 l6">
                  <input placeholder="Introduce tu correo electronico" id="email" type="email" name="email" class="validate">
                  <label for="email">Correo electronico</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s12 l6">
                  <input placeholder="Introduce tu contraseña" id="password"  type="password" class="validate">
                  <label for="password">Contraseña</label>
              </div>
            </div>
            <div class="row">
                <div class="input-field col s12 l6">
                    <button class="btn waves-effect waves-light col s6 l6 "  onclick="miLista()" type="button" id="enviar" >Iniciar Sesión
                <i class="material-icons right">person_pin</i>
                </button>
              <button class="btn waves-effect waves-light col s6 l6 " type="button" id="registro" name="hola" >Registrarse
                <i class="material-icons right">send</i>
                  </button>
                </div>
            </div>
          </form>
        </div>
        <!--Import jQuery before materialize.js-->
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
      <script>
      function miLista(){

      var $email = $("#email");
      var $password = $("#password");
      var form = new FormData();
      form.append("password", $password.val());
      form.append("email", $email.val());

      var settings = {
        "async": true,
        "crossDomain": true,
        "url": "http://localhost/slim/login",
        "method": "POST",
        "headers": {
          "cache-control": "no-cache",
          "postman-token": "daa3bc1a-f082-e6b4-a567-24313e9d9fa2"
        },
        "processData": false,
        "contentType": false,
        "mimeType": "multipart/form-data",
        "data": form
      }

      $.ajax(settings).done(function (response) {
        console.log(response);
        var objetos = jQuery.parseJSON(response);
        console.log(objetos);
        if(objetos == "si"){
            console.log('si');
           
            window.location.href="http://localhost:3000/";
        }else{
          console.log("nelson gemidos");
          
        }
      });

      }
      </script>
        <script type="text/javascript" src="js/materialize.min.js"></script>
    </body>
</html>